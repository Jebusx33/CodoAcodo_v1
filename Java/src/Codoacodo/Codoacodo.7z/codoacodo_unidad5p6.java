package Codoacodo;
//@author Jesus Arias
public class codoacodo_unidad5p6 {
/*
 6.- Realizar un programa que imprima los n�meros pares entre 0 y 100
*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 0, b = 100, i;

		
		i = a;
		while (i < b ) {
			System.out.println(i + "");
			i++; // i+= mas 1 y i-- es i-= menos1
			i++;
		}

	}
}
